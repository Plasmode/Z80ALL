;assming bootstrap code is already in CF
; a very small piece of code to boot from  CF
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Z80ALL Simple Bootstrap release 0.1 8/22/20
; (C)2020 H. SHEN
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
RxData  	equ 0f9h        	; CPLD UART receive register
TxData  	equ 0f9h        	; CPLD UART transmit register
RxStat  	equ 0f8h        	; CPLD UART transmitter status/control register
TxStat  	equ 0f8h        	; CPLD UART receiver status/control register

CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg


	nop
	nop
	nop
	nop
	ld hl,0b000h	;bootstrap code starts from 0xb000
; examine the serial data ready flag and CF busy flag to decide which device to bootstrap from.
readbsy:
	in a,(CFstat)	; read CF status 
	rla		; more compact way of checking busy bit
	jr c,readbsy
;	ld a,081h		;disable 8-bit transfer
;	out (CFerr),a
;	ld a,0EFh
;	out (CFstat),a
;chkbsy1:
;	in a,(CFstat)	;wait until command is completed
;	rla
;	jr c,chkbsy1
	ld c,CFdata	; reg C points to CF data reg
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
chkdrq:
	in a,(CFstat)	; check data request bit set before write CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,chkdrq

	inir		;z80 read 256 bytes
	jp 0b000h


	end



