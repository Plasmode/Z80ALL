;demonstrate Conway game of life on 48 line VGA
;expand the VGA graphic resolution by defining 16 fonts for 2x2 pixel
;  monitor resolution is now 128x96
;Life universe of 128x96 now lives in memory instead of video RAM
;
;rules:
; 4 or more cause death
; 3 causes birth
; 2 or 3 no change
; 1 or less causes death
; scan the whole map and mark for birth (0x29) or death (0x28)
; go over the whole map and convert 0x28 to 0 and 0x29 to 0x30
VGAfont	equ 2ch
VGAbase	equ 20h

	org 1000h

	ld sp,2000h
	call clearUniverse
;initialize 2x2 sub_block fonts
	ld b,0
	ld c,VGAfont
	ld hl,graphicFont
initGraphicFont:
	ld a,(hl)
	out (c),a
	inc hl
	inc b
	jp p,initGraphicFont
; setup initial condition			
	ld d,initend-init		;size of the initialization table
	ld bc,init		;point to initialization data
initloop:
;Life Universe is on 256-byte boundary so indexing is simpler
;init data are pairs of (line,cell) coordinate
	ld hl,Universe		;base is Life Universe
	ld a,(bc)			;point to line of init data pair
	add a,h
	ld h,a
	inc bc			;point to cell of init data pair
	ld a,(bc)
	ld l,a			;no need to add because regL is initially 0
	ld a,1			;the living cell value is 0x1
	ld (hl),a
	inc bc
	dec d
	dec d
	jp nz,initloop
	call writeVGA		;write initial values to display

	call delay
	call delay
	call delay
	call delay
life:
;scan from line 2 to line 95
	ld hl,Universe	;point to Life Universe which is on a 256-byte page boundary
	inc h		;start with second line
	inc l		;second cell
	ld b,94		;scan 94 lines
doLine:
	call scanline	;do a line at a time
	ld l,1		;next line
	inc h
	djnz doLine
; go over all cells and write 0 to cells marked for death and write 0x1 to cells
;   mark for birth
	ld hl,Universe	;point to Life Universe
	ld b,96
update96a:
	ld a,(hl)
	cp 080h		;0x80 is mark for birth
	jr nz,update96b
	ld a,1		;mark cell as living
	ld (hl),a
	jp update96c
update96b:
	cp 010h		;0x10 is mark for death
	jr nz,update96c
	xor a
	ld (hl),a 
update96c:
;do nothing, update next cell
	inc l
	jp p,update96a
	ld l,0
	inc h
	djnz update96a
	call writeVGA
	jp life
scanline:
;scan the life universe
;look at the 8 cells around the current postion
;scan a whole line
;reg H is line; reg L is cell of current position
;mark for birth is 0x80, mark for death is 0x10
;regL starts from 1
	dec l
	dec h		;line above
	ld a,(hl)		;get upper left cell
	inc l
	add a,(hl)	;add cell above
	inc l
	add a,(hl)	;add upper right cell
	inc h		;current line
	add a,(hl)	;add right cell
	dec l
	dec l
	add a,(hl)	;add left cell
	inc h		;line below
	add a,(hl)	;add lower left cell
	inc l
	add a,(hl)	;add lower cell
	inc l
	add a,(hl)	;add lower right cell
	and 07fh		;ignore mark-for-birth
	dec h
	dec l		;regHL points to current cell	
	ld e,a		;temporary save 
	and 0fh		;total number of living cells
	ld d,a		;temporary save
	ld a,e		
	and 0f0h		;get cells marked-for-death
	rrca
	rrca
	rrca
	rrca
	add d		;regA now has the total number of adjacent living cells
	cp 2		; if lesser than 2, mark for death; if 2, do nothing
	jp z,scan8
	jr c,death
	cp 3		;if 3 and living, nothing; if 3 and dead, mark-for-living
	jr z,chkstat
;4 or more living neighbors.  If dead, nothing; if living, mark-for-death
death:
	ld a,(hl)		;get current cell
	cp 0		;if cell not living, do nothing
	jp z,scan8
	ld a,010h		;else mark for death
	ld (hl),a
	jp scan8
chkstat:
;3 living neighbors; if cell is living, do nothing; if dead, mark-for-birth
	ld a,(hl)		;get current cell
	cp 0		
	jp nz,scan8	;cell is living, do nothing
	ld a,080h		;mark cell for birth
	ld (hl),a
scan8:
	inc l		;regHL points to next cell
	ld a,127
	cp l
	jp nz,scanline
	ret
writeVGA:
;each VGA character is 2x2 pixels
;scan two lines and two pixels to convert it to one VGA character
	ld hl,Universe
	ld c,VGAbase
	ld b,0		;start from upper left corner
wrPixel:
	ld a,(hl)
	ld d,a
	inc l
	ld a,(hl)
	rrca
	rl d
	inc h
	dec l
	ld a,(hl)
	rrca
	rl d
	inc l
	ld a,(hl)
	rrca
	rl d		;reg D contains the character value to be displayed
	out (c),d
	dec h
	inc b		;point to next character on VGA
	inc l		;next 4-pixel block
	jp p,wrPixel
	ld l,0
	inc h		;next line pair
	inc h
	xor a
	cp b		;reach end of block-of-4 line?
	jp nz,wrPixel
	inc c
	ld a,VGAfont
	cp c
	jp nz,wrPixel
	ret
delay:
	push bc
	push af
	ld bc,0
delay1:
	nop
	dec bc
	ld a,b
	cp 0
	jp nz,delay1
	pop af
	pop bc
	ret
clearUniverse:
;clear the Life Universe of 256x96
	ld hl,Universe
	xor a
	ld b,96		;loop count = 48
clrUniv1:
	ld (hl),a
	inc hl
	cp l
	jr nz,clrUniv1
	dec b
	jr nz,clrUniv1
	ret

graphicFont:
	db 0,0,0,0,0,0,0,0
	db 0,0,0,0,07h,07h,07h,07h			;one pixel, 
	db 0,0,0,0,070h,070h,070h,070h		;one pixel, 
	db 0,0,0,0,077h,077h,077h,077h		;two pixels, 
	db 07h,07h,07h,07h,0,0,0,0			;one pixel, 
	db 07h,07h,07h,0h,07h,07h,07h,07h		;5 two pixels, 
	db 07h,07h,07h,0h,070h,070h,070h,070h		;6 two pixels, 
	db 07h,07h,07h,0h,077h,077h,077h,077h		;7 three pixels
	db 070h,070h,070h,070h,0,0,0,0		;8 one pixel 
	db 070h,070h,070h,0h,07h,07h,07h,07h		;9 two pixels 
	db 070h,070h,070h,0h,070h,070h,070h,070h	;10 two pixels, 
	db 070h,070h,070h,0h,077h,077h,077h,077h	;11 pixels
	db 077h,077h,077h,077h,0,0,0,0		;12 pixel, 
	db 077h,077h,077h,0h,07h,07h,07h,07h		; 13 pixels
	db 077h,077h,077h,0h,070h,070h,070h,070h	;14 pixels
	db 077h,077h,077h,0h,077h,077h,077h,077h	;4 pixels

;	db 0,0,0,0,0,0,0,0
;	db 0,0,0,0,07h,07h,07h,07h			;one pixel, 
;	db 0,0,0,0,070h,070h,070h,070h		;one pixel, 
;	db 0,0,0,0,077h,077h,077h,077h		;two pixels, 
;	db 07h,07h,07h,07h,0,0,0,0			;one pixel, 
;	db 07h,07h,07h,07h,07h,07h,07h,07h		;5 two pixels, 
;	db 07h,07h,07h,07h,070h,070h,070h,070h		;6 two pixels, 
;	db 07h,07h,07h,07h,077h,077h,077h,077h		;7 three pixels
;	db 070h,070h,070h,070h,0,0,0,0		;8 one pixel 
;	db 070h,070h,070h,070h,07h,07h,07h,07h		;9 two pixels 
;	db 070h,070h,070h,070h,070h,070h,070h,070h	;10 two pixels, 
;	db 070h,070h,070h,070h,077h,077h,077h,077h	;11 pixels
;	db 077h,077h,077h,077h,0,0,0,0		;12 pixel, 
;	db 077h,077h,077h,077h,07h,07h,07h,07h		; 13 pixels
;	db 077h,077h,077h,077h,070h,070h,070h,070h	;14 pixels
;	db 077h,077h,077h,077h,077h,077h,077h,077h	;4 pixels

;	db 0,0,0,0,0,0,0,0
;	db 0,0,0,0,0fh,0fh,0fh,0fh			;one pixel, lower right
;	db 0,0,0,0,0f0h,0f0h,0f0h,0f0h		;one pixel, upper right
;	db 0,0,0,0,0ffh,0ffh,0ffh,0ffh		;two pixels, right side
;	db 0fh,0fh,0fh,0fh,0,0,0,0			;one pixel, lower left
;	db 0fh,0fh,0fh,0fh,0fh,0fh,0fh,0fh		;5 two pixels, lower half
;	db 0fh,0fh,0fh,0fh,0f0h,0f0h,0f0h,0f0h		;6 two pixels, diagnal
;	db 0fh,0fh,0fh,0fh,0ffh,0ffh,0ffh,0ffh		;7 three pixels
;	db 0f0h,0f0h,0f0h,0f0h,0,0,0,0		;8 one pixel upper left
;	db 0f0h,0f0h,0f0h,0f0h,0fh,0fh,0fh,0fh		;9 two pixels diagnal
;	db 0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h	;10 two pixels, upper half
;	db 0f0h,0f0h,0f0h,0f0h,0ffh,0ffh,0ffh,0ffh	;11 pixels
;	db 0ffh,0ffh,0ffh,0ffh,0,0,0,0		;12 pixel, left half
;	db 0ffh,0ffh,0ffh,0ffh,0fh,0fh,0fh,0fh		; 13 pixels
;	db 0ffh,0ffh,0ffh,0ffh,0f0h,0f0h,0f0h,0f0h	;14 pixels
;	db 0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh	;4 pixels
init:
;glide gun initialization data
	db 1h,26		;initial data, organized (line,pixel) pair
	db 2h,24
	db 2h,26
	db 3h,14
	db 3h,15
	db 3h,22
	db 3h,23
	db 3h,36
	db 3h,37
	db 4h,13
	db 4h,17
	db 4h,22
	db 4h,23
	db 4h,36
	db 4h,37
	db 5h,2
	db 5h,3
	db 5h,12
	db 5h,18
	db 5h,22
	db 5h,23
	db 6h,2
	db 6h,3
	db 6h,12
	db 6h,16
	db 6h,18
	db 6h,19
	db 6h,24
	db 6h,26
	db 7h,12
	db 7h,18
	db 7h,26
	db 8h,13
	db 8h,17
	db 9h,14
	db 9h,15
initend:				;end of initialization data
	org 02000h
Universe:
;this is the 128x96 Life universe
;to simplify algorithm, 128 pixel takes a page (256 bytes),
;  so the life universe is 24K bytes (256x96)

