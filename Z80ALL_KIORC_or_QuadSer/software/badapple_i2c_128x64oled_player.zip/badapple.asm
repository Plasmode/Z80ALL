; 6/18/22 BadApple!! for 128x64OLED (SSD1306 controller)
; data file stored as first file of drive D, start on track 0xC0 sector 0x20
; bit bang the I2C at I/O address  09E
; D0 is clock (SCL) D7 is data (SDA)
I2C	equ 9eh		;bit bang I/O address of I2C
;;; CF interface registers
CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

	org 1000h
	jp start
error:	db 0
track	ds 2
sector	ds 1
start:
	ld sp,2000h
	di
	xor a
	ld (error),a	;clear error flag
	ld hl,error	;point to error flag

	ld d,0feh		;initialize regD for wi2cN routine use
	call i2cs		;start
	ld c,078h		;SSD1306 address
	call wi2cN
	ld c,0aeh		;turn off display
	call wi2cN
   	ld c,0d5h		;set display clock div
	call wi2cN
	ld c,080h		;ratio  080
	call wi2cN
	ld c,000h		;set multiplex
	call wi2cN
	ld c,03fh		; 128x32
	call wi2cN
	ld c,0d3h		;set display offset
	call wi2cN
	ld c,000h		
	call wi2cN		
	ld c,040h		;set startline
	call wi2cN
	ld c,08dh		;charge pump
	call wi2cN
	ld c,014h		;vccstate 14
	call wi2cN
	ld c,020h		;memorymode
	call wi2cN
	ld c,000h		
	call wi2cN
;	ld c,0a1h		;a0 upside down segremap
;	call wi2cN
;	ld c,0c8h		;com scan dec
;	call wi2cN
	ld c,0dah		;set com pins
	call wi2cN
	ld c,012h		; 02 128x32 12
	call wi2cN
	ld c,081h		; set contrast
	call wi2cN
	ld c,0ffh		;contrast
	call wi2cN
	ld c,0d9h		;set precharge
	call wi2cN
	ld c,0f1h		;vcc state f1
	call wi2cN
	ld c,0dbh		;set vcom detect
	call wi2cN
	ld c,040h
	call wi2cN
	ld c,0a4h		;display all on resume
	call wi2cN
	ld c,0a6h		;normal display
	call wi2cN

	ld c,0afh		;display on
	call wi2cN
	call i2cp		;I2C stop

	xor a
	ld (track+1),a	;BadApple image stored on track 0xc0, sector 0x20
	ld a,0c0h
	ld (track),a
	ld a,01fh
	ld (sector),a
spinn:
	ld hl,table	;point to buffer
	call nxtImage	;one sector (512bytes) image
	call nxtImage
	call wwdat	;write image to I2C
	call delay
	jp spinn
	
	jp 0b400h		;exit to monitor
delay:
;delay for a while
;adjust this delay for 50mS per frame
	push de
	ld de,6d00h		;delay
inner:
	dec e
	jp z,delay1
	jr inner
delay1:
	dec d
	jp z,delay2
	jr inner
delay2:	
	pop de
	ret
nxtImage:
;fetch next image from CF disk
;image stored starts from track 0xC0, sector 0x20
;2 sectors per image (1K bytes)
	push bc
	ld a,(sector)	;get sector value
	inc a
	jr nz,nxtImage1
	push af
	ld a,(track)	;get track value
	inc a
	ld (track),a
	pop af
nxtImage1:
	ld (sector),a	;save updated sector
	out (CF07),a	; write LSB CF LA address
	ld a,1		; read one sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,(track)	; get LSB track address
	out (CF815),a	; write to CF LA register
	ld a,(track+1)	; get MSB track address
	out (CF1623),a	; write to CF LA register, MSB
	ld a,20h		; read CF sector command
	out (CFstat),a	; issue the CF read sector comand
	call readdrq	; check drq bit set before read CF data
	ld c,CFdata	; reg C points to CF data reg
	ld b,0h		; sector has 512 8-bit data
	inir		;;256 bytes
	inir		;;256 bytes
	pop bc
	ret
readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq
	ret
wwdat:
; write entire screen of data
	ld d,0feh		;regD initialized for wi2cN routine
	ld b,0
	call i2cs		;start
	ld c,078h		;SSD1306 address
	call wi2cN
	ld c,40h		;data
	call wi2cN
	ld hl,table	;point to screen data set
wwdat1:
;write 1K bytes of data
	ld c,(hl)
	call wi2cN
	inc hl
	ld c,(hl)
	call wi2cN
	inc hl
	ld c,(hl)
	call wi2cN
	inc hl
	ld c,(hl)
	call wi2cN
	inc hl
	djnz wwdat1
	jr i2cp		;stop I2Chreturn to calling routine

i2cs:
	ld a,0ffh
	out (I2C),a	;set SCL and SDA high
	nop
	nop
	nop
	ld a,1
	out (I2C),a	;START
	nop
	nop
	nop
	xor a
	out (I2C),a	;clock low
	ret
i2cp:
;STOP
	xor a		;clock lowhdata low
	out (I2C),a
	ld a,1		;clock highhdata low
	out (I2C),a
	nop
	nop
	ld a,0ffh		;data goes high while clock high (STOP)
	out (I2C),a
	ret
wi2cN:
;a different (faster) version of I2C bit bang
;SCL is D[0], SDA is D[7], other bits are don't care
;regD is initialized to 0xFE
;I2C protocol sent msb first and lsb last
	ld a,c
	and d		;set clock low, also reset carry flag
	out (I2C),a	;output msb while clock low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
;done the msb, now do the next 7 bit
	ld a,c
wi2cN1:
; enter this loop with clock low
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
;unroll the loop for faster speed
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a
	rla		;next bit into SDA, SCL gets carry which is 0
	out (I2C),a	;change data while clock is low
	inc a		;set clock high
	out (I2C),a
;	nop
	and d		;set clock low, also reset carry flag
	out (I2C),a

;slave acknowledgement
;May ignore slave acknowledge to increase bit-bang speed
	ld a,80h		;wait for acknowledge
	out (I2C),a		
	inc a		;clock high with data high expect slave to pull it low
	out (I2C),a
	nop
	nop
	in a,(I2C)	;read slave acknowledge
	and 80h		;expect it to be low for slave acknowledge
	jp nz,errormsg
	dec a
	out (I2C),a	;clock low with data high
	ret
errormsg:

	
	ld a,1
	out (I2C),a	;clock high data low
	nop
	nop
	ld a,(error)
	or 80h
	ld (error),a	;set error flag
	nop
	nop
	nop
	nop
	ld a,0ffh
	out (I2C),a	;data low to high while clock high (STOP)

	jp 0b400h		;return to command prompt
table:

