;2/27/23 adapted from ZAQSerld
;assuming the console port is KIORC
; 3/30/22 adapted from ZRCC serial loader
; console port is now Quad Serial Channel 0
; Autostart from 0xB400 after the 2nd file is loaded
; serial port bootstrap code
; file load program fit in 256 bytes
; File is intel HEX format
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Z80ALL Serial Loader, Rev0.0
; (C) 2020 Hui-chien Shen
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

KioData  	equ 088h        	; KIO channel A Data
KioStat  	equ 089h        	; KIO channel A cmd/status
	
	org 0b000h	; this is the starting address of serial loaded program
          LD SP,0FFFFH  	; initialize stack pointer to top of memory
	ld a,3		;initialize QuadSer chan0
	out (0c3h),a	;8-bit data
	ld a,1
	out (0c7h),a	;ICR offset to SPR register
	ld a,06ch		;divisor value for 115200 baud
	out (0c5h),a
	ld hl,SignOn$	; print the sign on message
	call strout
	ld a,80h		; page out the ROM in CPLD
	out (1fh),a	; bit 4 of bank select
main:
	call cinq
	cp ':'			; intel load file starts with :
	jr nz,main
fileload:
	call GETHEX	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a			; save byte count to reg D
	ld b,a			; initialize the checksum
	call GETHEX	; get MSB of address
	ld h,a			; HL points to memory to be loaded
	add a,b			; accumulating checksum
	ld b,a			; checksum is kept in reg B
	call GETHEX	; get LSB of address
	ld l,a
	add a,b			; accumulating checksum
	ld b,a			; checksum is kept in reg B
	call GETHEX	; get the record type, 0 is data, 1 is end
	cp 0
	jr z,filesave
	cp 1				; end of file transfer?
	jr nz,unknown	; if not, print a 'U'
; end of the file load
	call GETHEX	; flush the line, get the last byte
	ld a,'X'		; mark the end with 'X'
	call cout
	ld a,10			; carriage return and line feed
	call cout
	ld a,13
	call cout
;	jr main
	jp 0b400h		;assume the loaded file start from 0xB400

; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b			; accumulating checksum of record type
	ld b,a			; checksum is kept in reg B
filesav1:
	call GETHEX	; get a byte
	ld (hl),a		; save to destination
	add a,b			; accumulating checksum
	ld b,a			; checksum is kept in reg B
	inc hl
	dec d
	jr nz,filesav1
	call GETHEX	; get the checksum
	neg a			; 2's complement
	cp b				; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'
	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr main			; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
	jr main

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GETHEX -- Get byte from console as hex
;
;pre: none
;post: A register contains byte from hex input
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GETHEX:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ASCHEX -- Convert ASCII coded hex to nybble
;
;pre: A register contains ASCII coded nybble
;post: A register contains nybble
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ASCHEX: 	SUB 30h
        	CP 0Ah
        	RET M
        	AND 5Fh
        	SUB 07h
        	RET
; string output
; output string pointed by HL until null terminator
strout:
	ld a,(hl)		;get next character
	cp 0		;null terminator?
	ret z		;return if null terminator
	call cout		; put out a character
	inc hl		; next char in the string
	jr strout
; output char in reg A
; bit bang the transmit for Z80SBC64
cout:
	push af
cout1:
	in a,(KioStat)
	bit 2,a		;bit 2 is TxEmpty
	jr z,cout1
	pop af
	out (KioData),a
	ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;CINQ -- Get a char from the console and no echo
;
;pre: console device is initialized
;post: received char is in A register
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; RxRdy status bit is D[0] for Z80SBC64
cinq:    
	in a,(KioStat)	;read status
	and 1		;data ready flag is in D[0]
	jr z,cinq
	in a,(KioData)	; read data
	ret

SignOn$: 	db 0ah,0dh,"ZALLK Loader v0.1",0ah,0dh
	db "Auto start at 0xB400",0ah,0dh,0

	db 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	db 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
	db 0	; pad to exactly 255 bytes

	end
