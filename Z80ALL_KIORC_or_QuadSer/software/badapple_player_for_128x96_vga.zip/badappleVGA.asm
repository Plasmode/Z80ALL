;display Bad Apple file on VGA monitor
VGAbase	equ 20h
VGAfont	equ 2ch
I2C	equ 9eh		;bit bang I/O address of I2C
;;; CF interface registers
CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

	org 1000h
	jp start
error:	db 0
offset:	db 0
track	ds 2
sector	ds 1
VGArow	ds 1
start:
	ld sp,2000h
	di
	xor a
	ld (error),a	;clear error flag
	ld hl,error	;point to error flag
;clear screen
	ld b,0
	ld c,VGAbase
	xor a
clrBO4:
	out (c),a
	inc b
	jr nz,clrBO4
	inc c
	ld a,VGAfont
	cp c
	jr nz,clrBO4
;initialize font
	ld b,0
	ld c,VGAfont
	ld hl,graphicFont
initGraphic:
	ld a,(hl)
	out (c),a
	inc hl
	inc b
	jp p,initGraphic

	xor a
	ld (track+1),a
	ld a,0c0h
	ld (track),a
	ld a,01fh
	ld (sector),a
	ld b,20
spinn:
	push bc
	ld a,VGAbase
	ld (VGArow),a
	call nxtSectImg
;write caption to first line
	push bc
	push hl
	ld b,0			;first line
	ld c,VGAbase
	ld hl,Caption
Caption1:
	ld a,(hl)
	cp 0
	jr z,endCaption
	out (c),a
	inc b
	inc hl
	jr Caption1
endCaption:
	ld b,64			;second line
	ld hl,Track_Sect
trackSect1:
	ld a,(hl)
	cp 0
	jr z,endTS
	out (c),a
	inc b
	inc hl
	jr trackSect1
endTS:
	ld a,(track)
	call HEXOUT
	ld a,(HexHi)		;display track value, high nibble
	out (c),a
	inc b
	ld a,(HexLo)		;display track value, low nibble
	out (c),a
	inc b
	ld a,':'			;track/sector separator
	out (c),a
	inc b
	ld a,(sector)
	call HEXOUT
	ld a,(HexHi)		;display sector value
	out (c),a
	inc b
	ld a,(HexLo)
	out (c),a
	pop hl
	pop bc
	ld a,VGAbase+4
	ld (VGArow),a
	call nxtSectImg
	ld a,VGAbase+8
	ld (VGArow),a
	call nxtSectImg
	call delay


	pop bc
	dec b

	jp spinn
	jp nz,spinn
	jp $
	
	jp 0b400h

HEXOUT: 	
	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	ld (HexHi),a		;save to local variable
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	ld (HexLo),a		;save to local variable
        	POP BC
        	RET
HEXASC:
;convert nibble to ASCII 	
	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET
HexHi:	ds 1
HexLo:	ds 1
delay:
;delay for a while
	push de
	ld de,9600h		;delay
inner:
	dec e
	jp z,delay1
	jr inner
delay1:
	dec d
	jp z,delay2
	jr inner
delay2:	
	pop de
	ret
nxtSectImg:
;fetch next image from CF disk
;image stored starts from track 0xC0, sector 0x20
;2 sectors per image (1K bytes)
;variable VGArow is the base row of the image
	push bc
	push de
	ld a,(sector)	;get sector value
	inc a
	jr nz,nxtImage1
	push af
	ld a,(track)
	inc a
	ld (track),a
	pop af
nxtImage1:
	ld (sector),a	;save updated sector
	out (CF07),a	; write LSB CF LA address
	ld a,1		; read one sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,(track)	; get LSB track address
	out (CF815),a	; write to CF LA register
	ld a,(track+1)	; get MSB track address
	out (CF1623),a	; write to CF LA register, MSB
	ld a,20h		; read CF sector command
	out (CFstat),a	; issue the CF read sector comand
	call readdrq	; check drq bit set before read CF data
	ld a,(VGArow)	;start from first block-of-4
	ld c,a
Do1Sector:
	ld b,0c0h		;initialize cursor to leftmost position of 4th line of block-of-4
BO4:
;read two bytes from CF.  Convert it to appropriate font
	in a,(CFdata)	;get two bytes into reg D, E
	ld d,a
	in a,(CFdata)
	ld e,a
;process the 4th line of block-of-4
;Most significant two bits of reg D & E are 4th line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A now contains the 4 pixel info
	out (c),a		;write the 4-pixel data to calculated location of VGA display
; calculate the 4-pixel data for 3rd line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A ow contains the 4-pixel info for 3rd line
	res 6,b		;reg B points to 3rd line of block-of-4
	out (c),a		;write out the 4-pixel data
;calculate the 4-pixel data for 2nd line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A ow contains the 4-pixel info for 3rd line
	res 7,b
	set 6,b		;reg B points to 2nd line of block-of-4
	out (c),a		;write out the 4-pixel data
;calculate the 4-pixel data for 1st line of block-of-4
	xor a
	rlc d
	rla
	rlc d
	rla
	rlc e
	rla
	rlc e
	rla		;reg A ow contains the 4-pixel info for 3rd line
	res 6,b		;reg B points to 2nd line of block-of-4
	out (c),a		;write out the 4-pixel data

	set 6,b
	set 7,b
	inc b
	jp nz,BO4
	inc c
	ld a,c
	and 3
	jp nz,Do1Sector
;finish reading CF sector of 512 byte of data
	pop de
	pop bc
	ret
readdrq:
	in a,(CFstat)	; check data request bit set before read CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jp z,readdrq
	ret
Caption:
	db "BadAppleVGA Rev 0.1",0
Track_Sect:
	db "Track:Sector ",0
graphicFont:
	db 0,0,0,0,0,0,0,0
	db 0fh,0fh,0fh,0fh,0,0,0,0			;one pixel, lower right
	db 0,0,0,0,0fh,0fh,0fh,0fh			;one pixel, upper right
	db 0fh,0fh,0fh,0fh,0fh,0fh,0fh,0fh		;two pixels, right side
	db 0f0h,0f0h,0f0h,0f0h,0,0,0,0		;one pixel, lower left
	db 0ffh,0ffh,0ffh,0ffh,0,0,0,0		;two pixels, lower half
	db 0f0h,0f0h,0f0h,0f0h,0fh,0fh,0fh,0fh		;two pixels, diagnal
	db 0ffh,0ffh,0ffh,0ffh,0fh,0fh,0fh,0fh		;three pixels
	db 0,0,0,0,0f0h,0f0h,0f0h,0f0h		;one pixel upper left
	db 0fh,0fh,0fh,0fh,0f0h,0f0h,0f0h,0f0h		;two pixels diagnal
	db 0,0,0,0,0ffh,0ffh,0ffh,0ffh		;two pixels, upper half
	db 0fh,0fh,0fh,0fh,0ffh,0ffh,0ffh,0ffh		;3 pixels
	db 0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h,0f0h	;2 pixel, left half
	db 0ffh,0ffh,0ffh,0ffh,0f0h,0f0h,0f0h,0f0h	; 3 pixels
	db 0f0h,0f0h,0f0h,0f0h,0ffh,0ffh,0ffh,0ffh	;3 pixels
	db 0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh,0ffh	;4 pixels




