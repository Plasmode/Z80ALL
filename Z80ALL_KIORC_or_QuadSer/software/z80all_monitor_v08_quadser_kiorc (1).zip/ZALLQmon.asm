;3/30/33 ported from ZALLMon version 0.3
;console port is now Quad Serial channel 0
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ZALLQMon, Copyright (C) 2022 Hui-chien Shen
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
QuadSer	equ 0c0h		;Quad Serial base address
SerData  	equ 0c0h        	; Quad Serial Channel 0 data
SerStat  	equ 0c5h        	; Quad Serial Channel 0 status

CFdata   	equ 010h    	;CF data register
CFerr    	equ 011h    	;CF error reg
CFsectcnt equ 012h    	;CF sector count reg
CF07     	equ 013h   	;CF LA0-7
CF815    	equ 014h       	;CF LA8-15
CF1623   	equ 015h       	;CF LA16-23
CF2427   	equ 016h       	;CF LA24-27
CFstat   	equ 017h       	;CF status/command reg

VGAtext	equ 20h		;base I/O address of VGA text display
VGAfont	equ 2ch		;base I/O address of VGA text font table
PS2Data	equ 0f4h		;PS2 keyboard input
PS2Stat	equ 0f5h		;PS2 keyboard status, bit 0 indicate data available

KIOBase	equ 80h
SIOBCmd	equ 8bh		;SIO channel B
SIOBDat	equ 8ah
SIOACmd	equ 89h		;SIO channel A
SIOADat	equ 88h

bankReg	equ 01fh		; Z80SBC64 bank control register
; write only register
; power on value is 0x3
; write 0x0 for normal mode of operation
; write 0x2 for bank 0
; common area is at top 32K
; write '1' to data bit 7 to disable the 64-byte ROM in CPLD

VGAline12	equ 20h		;first 4 line of VGA display
	ORG 0b400H
; This part of the program will be relocated to 0x400 post process		
	jp start
	jp CMD		;warm start address is 0xb403
; variable area
testseed: ds 2		; RAM test seed value
addr3116:	ds 2		; high address for Intel Hex format 4
RDsector:	ds 1		; current RAM disk sector
RDtrack:	ds 1		; current RAM disk track 
RDaddr:	ds 2		; current RAM disk address 
sectoff:	ds 2		; offset from a track & sector
currbank:	ds 1		;current RAM bank
cursor:	ds 2		;cursor position
prevChar	ds 1		;previous character overwritten by cursor
fPS2Rel	ds 1		;Release PS2 key 
fShift	ds 1		;PS2 SHIFT key flag
fCtrl	ds 1		;PS2 CTRL key flag
fCapLock	ds 1		;PS2 CapLock key flag
fPS2Buf	ds 1		;flag indicates valid data in bPS2
bPS2	ds 1		;buffer for PS2 keyboard input
fKIO	ds 1		;KIO present flag
fQuadSer	ds 1		;QuadSerial present flag
temp	ds 1		;temporary storage
;;initialization routines
SIOAinit:
;reg C contains the address of SIO control register
            LD   HL,SIOIni     ;Point to initialisation data
            LD   B,9 	;Length of ini data
            OTIR                ;Write data to output port C
            XOR  A              ;Return Z flag as device found
            RET
; SIO channel initialisation data
SIOIni:    DB  18h     ; Wr0 Channel reset

            DB  14h    ; Wr0 Pointer R4 + reset ex st int
;            DB  0c4h     ; Wr4 /64, async mode, no parity
            DB  044h     ; Wr4 /16, async mode, no parity
            DB  3     ; Wr0 Pointer R3
            DB  0c1h     ; Wr3 Receive enable, 8 bit 
            DB  5     ; Wr0 Pointer R5
            DB  0eah     ; Wr5 Transmit enable, 8 bit, flow ctrl
            DB  11h     ; Wr0 Pointer R1 + reset ex st int
            DB  0     ; Wr1 No Tx interrupts
;            DB  40h     ; Wr1 No Tx interrupts, set READY high
QuadSerIni:
;initialize QuadSerial board
	ld a,3		;initialize QuadSer chan0
	out (0c3h),a	;8-bit data
	ld a,1
	out (0c7h),a	;ICR offset to SPR register
	ld a,06ch		;divisor value for 115200 baud
	out (0c5h),a
	ret
;Initialization and sign-on message
start:
	ld sp,0b400h	; initialize stack just below program
	ld hl,020h	;initialize cursor position
	ld (cursor),hl
	xor a
	ld (fPS2Rel),a	;clear key release flag
	ld (fShift),a	;clear PS2 SHIFT key flag
	ld (fCtrl),a	;clear PS2 CTRL key flag
	ld (fCapLock),a	;clear PS2 CapLock key flag
	ld (fPS2Buf),a	;clear flag for valid PS2 flag 
	ld (fKIO),a	;clear KIO present flag
	ld (fQuadSer),a	;clear Quad Serial present flag
	in a,(PS2Data)	;read clear spurious data from PS2 keyboard
;auto detect KIO at $80 by checking interrupt vector register
	ld a,2		;interrupt vector is write reg 2
	out (SIOBCmd),a
	xor a
	out (SIOBCmd),a	;clear interrupt vector
	ld a,2
	out (SIOBCmd),a
	ld a,5ah		;test pattern
	out (SIOBCmd),a
	ld a,2
	out (SIOBCmd),a	
	in a,(SIOBCmd)	;read back the test pattern
	cp 5ah
	jr z,useKIO
;did not find KIO, look for QuadSer
;check DLAB function
	xor a
	out (QuadSer+1),a	;IER = 0
	ld a,80h
	out (QuadSer+3),a	;LCR=80, DLAB bit on, DLAB is now enabled
	ld a,5ah		;test pattern
	out (QuadSer+1),a	;write DLM
	xor a
	out (0),a		;precharge the data bus with 0x0
	in a,(QuadSer+1)	;read it back
	cp 5ah
	jr nz,noROM	;branch if QSer not present
	xor a
	out (QuadSer+1),a	;clear DLM
	out (QuadSer+3),a	;LCR=0, disable DLAB

	ld a,1
	ld (fQuadSer),a	;set Quad Serial present flag
	call QuadSerIni
    	LD HL,signon$	;sign on message
        	CALL strout
	ld hl,QuadSer$	;output "KIO detected"
	call strout
	jr noROM
useKIO:
	ld a,1
	ld (fKIO),a	;set KIO present flag
	ld c,SIOACmd	;initialize SIO chan A
	call SIOAinit
    	LD HL,signon$	;sign on message
        	CALL strout
	ld hl,KIO$	;output "KIO detected"
	call strout
	ld hl,detected$
	call strout
noROM:
	ld a,80h		; page away CPLD ROM
	out (bankReg),a	;
          xor a
	ld (sectoff),a	;initialize (clear) sector offset
	ld (sectoff+1),a
;no need to check for CF present.  CF must be present for Z80ALL to work
	call readbsy	;;8 wait until busy flag is cleared
	ld a,0e0h		;;8 set up LBA mode
	out (CF2427),a	;;8
	ld a,1		;;8 set feature to 8-bit interface
	out (CFerr),a	;;8
	ld a,0efh		;;8 set feature command
	out (CFstat),a	;;8
	call readbsy	;;8 wait until busy flag is cleared

;serial port emulator will see a command prompt
;VGA monitor will see the splash screen
;first command will cause splash screen to be cleared and VGA monitor will see
; same data as the serial port emulator
	ld hl,PROMPT$	;print prompt to serial port emulator
	call strout
;load the font as well as splash screen stored in sectors 0xf0-0xf7 of the CF disk
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld d,0f0h		;get 4K data starting from track 0, sector 0xF0
	ld c,VGAline12	;point to VGA dual port starting address
	ld b,0
morevga:
	ld a,1		;read 1 sector
	out (CFsectcnt),a	;write to sector count reg
	ld a,d
	cp 0f8h		;sectors 0xF0-0xF7
	jp z,initseed
	out (CF07),a
	ld a,20h		;read sector command
	out (CFstat),a	;issue the read command
	call chkdrq
first256:
	in a,(CFdata)	;get a byte from CF
	out (c),a		;copy data from CF to VGA dual port
	inc b
	jr nz,first256
;done 4 VGA lines, still have 256 bytes in CF buffer
	inc c		;next 4 lines
second256:
	in a,(CFdata)	;continue to get a byte from CF, 512 bytes total
	out (c),a		;copy data from CF to VGA dual port
	inc b
	jr nz,second256
;done one CF sector, do 7 more sectors
	inc c
	inc d
	jr morevga

initseed:
	ld hl,251		; initialize RAM test seed value
	ld (testseed),hl	; save it
clrRx:
;check for input data, read flush PS2/KIO/QuadSer if data present 
	call const
          jr z,clrVGA	;branch if no input data
	in a,(SerData)	;read clear Quad Serial
	in a,(SIOADat)	;read clear KIO
	xor a
	ld (fPS2Buf),a	;clear PS2 data available flag
	jr clrRx
clrVGA:
	call cinq		;any key will clear the VGA monitor
;check whether it is intel hex file load.  If file load, don't have time to erase VGA
;  screen, jump directly to Intel hex load routine
	cp ':'
	jp z,initload	;no time to clear VGA display, jump to intel hex load routine
	push af
	ld c,020h		;start with first line of VGA display
	ld b,0
clrVGA1:
	xor a
clrVGA2:
	out (c),a		;clear VGA display
	inc b
	jr nz,clrVGA2
	inc c
	ld a,2ch		;top of VGA display
	cp c
	jr nz,clrVGA1
	ld hl,020h	;initialize cursor position
	ld (cursor),hl
	pop af
	jr CMDLP2

;Main command loop
CMD:  	LD HL, PROMPT$
        	CALL strout
CMDLP1:
        	CALL cinq
CMDLP2:
	cp ':'		; Is this Intel load file?
	jr z,initload
	cp 0ah		; ignore line feed
	jr z,CMDLP1
	cp 0dh		; carriage return get a new prompt
	jr z,CMD
	CALL cout		; echo character
        	AND 5Fh
	cp 'H'		; help command
	jp z,HELP
        	CP A,'D'
        	JP Z,MEMDMP
        	CP A,'E'
        	JP Z,EDMEM
	cp a,'I'		; read data from specified I/O port in page 0
	jp z,INPORT
	cp a,'O'		; write data to specified I/O port in page 0
	jp z,OUTPORT
	cp a,'L'		; list memory as Intel Hex format
	jp z,LISTHEX
        	CP A,'G'
        	jp z,go		
	cp a,'R'		; read a CF sector
	jp z,READRD
	cp a,'Z'		; fill memory with zeros
	jp z,fillZ
	cp a,'F'		; fill memory with ff
	jp z,fillF
	cp a,'C'		; Copy to CF	
	jp z,COPYCF
	cp a,'T'		; testing RAM 
	jp z,TESTRAM
	cp 'B'		; boot CPM
	jp z,BootCPM
	cp 'X'		; clear CF directory
	jp z,format
what:
        	LD HL, what$
        	CALL strout
        	jr CMD
abort:
	ld hl,abort$	; print command not executed
	call strout
	jp CMD
; initialize for file load operation
initload:
	ld hl,0		; clear the high address in preparation for file load
	ld (addr3116),hl	; addr3116 modified with Intel Hex format 4 
; load Intel file
fileload:
	call GETHEXQ	; get two ASCII char (byte count) into hex byte in reg A
	ld d,a		; save byte count to reg D
	ld c,a		; save copy of byte count to reg C
	ld b,a		; initialize the checksum
	call GETHEXQ	; get MSB of address
	ld h,a		; HL points to memory to be loaded
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get LSB of address
	ld l,a
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the record type, 0 is data, 1 is end
	cp 0
	jp z,filesave
	cp 1		; end of file transfer?
	jr z,fileend
	cp 4		; Extended linear address?
	jp nz,unknown	; if not, print a 'U'
; Extended linear address for greater than 64K
; this is where addr3116 is modified
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld a,d		; byte count should always be 2
	cp 2
	jr nz,unknown
	call GETHEXQ	; get first byte (MSB) of high address
	ld (addr3116+1),a	; save to addr3116+1
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
; Little Endian format.  MSB in addr3116+1, LSB in addr3116
	call GETHEXQ	; get the 2nd byte (LSB) of of high address
	ld (addr3116),a	; save to addr3116
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'
	ld a,'E'		; denote a successful Extended linear addr update
	jr filesav2
; end of the file load
fileend:
	call GETHEXQ	; flush the line, get the last byte
	ld a,'X'		; mark the end with 'X'
	call cout
	ld a,10			; carriage return and line feed
	call cout
	ld a,13
	call cout
	jp CMD
; the assumption is the data is good and will be saved to the destination memory
filesave:
	add a,b		; accumulating checksum of record type
	ld b,a		; checksum is kept in reg B
	ld ix,0c000h	; 0c000h is buffer for incoming data
filesavx:
	call GETHEXQ	; get a byte
	ld (hl),a		;Z80SBC save data to destination
	add a,b		; accumulating checksum
	ld b,a		; checksum is kept in reg B
	inc ix
	inc hl		;Z80SBC 
	dec d
	jr nz,filesavx
	call GETHEXQ	; get the checksum
	neg a		; 2's complement
	cp b		; compare to checksum accumulated in reg B
	jr nz,badload	; checksum not match, put '?'

	ld a,'.'		; checksum match, put '.'
filesav2:
	call cout
	jr flushln	; repeat until record end
badload:
	ld a,'?'		; checksum not match, put '?'
	jr filesav2
unknown:
	ld a,'U'		; put out a 'U' and wait for next record
	call cout
flushln:
	call cinq		; keep on reading until ':' is encountered
	cp ':'
	jr nz,flushln
	jp fileload
; format CF drives directories unless it is RAM disk
; drive A directory is track 1, sectors 0-0x1F
; drive B directory is track 0x40, sectors 0-0x1F
; drive C directory is track 0x80, sectors 0-0x1F
; drive D directory is track 0xC0, sectors 0-0x1F
format:
	ld hl,clrdir$	; command message
	call strout
	call cin
	cp 'A'
	jr z,formatA	; fill track 1 sectors 0-0x1F with 0xE5
	cp 'B'
	jr z,formatB	; fill track 0x40 sectors 0-0x1F with 0xE5
	cp 'C'
	jr z,formatC	; fill track 0x80 sectors 0-0x1F with 0xE5
	cp 'D'
	jr z,formatD	; fill track 0xC0 sectors 0-0x1F with 0xE5
	jp abort		; abort command if not in the list of options
formatA:
	ld de,100h	; start with track 1 sector 0
	jr doformat
formatB:
	ld de,4000h	; start with track 0x40 sector 0
	jr doformat
formatC:
	ld de,8000h	; start with track 0x80 sector 0
	jr doformat
formatD:
	ld de,0c000h	; start with track 0xC0 sector 0
doformat:
;	ld hl,confirm$	; confirm command execution
	ld hl,xwarn$
	call strout
	call tstY
;	call tstCRLF
	jp nz,abort	; abort command if not CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; MSB track is 0
	ld a,d		; reg D contains the track info
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
	ld hl,0e5e5h	; value for empty directories
wrCFf:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,e		; write CPM sector
	cp 20h		; format sector 0-0x1F
	jp z,wrCFdonef	; done formatting
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	; check data request bit set before write CF data

	ld b,0h		; sector has 256 16-bit data
loopf:
	out (c),h		;z80 writes 2 bytes to CF
	out (c),h	
	inc b
	jp nz,loopf
	call readbsy	;wait on CF status busy bit

	inc e		; write next sector
	jp wrCFf
wrCFdonef:
	ld hl,done$
	call strout
	jp CMD

chkdrq:
	in a,(CFstat)	; check data request bit set before write CF data
	and 8		; bit 3 is DRQ, wait for it to set
	jr z,chkdrq
	ret
INPORT:
; read data from specified I/O port in page 0
; command format is "I port#"
; 
	ld hl,inport$	; print command 'I' prompt
	call strout
	call GETHEX	; get port # into reg A
	jp c,CMD		;abort for non-hex input
	jp z,CMD
	push bc		; save register
	ld c,a		; load port # in reg C
	in b,(c)		; get data from port # into reg B
	ld hl,invalue$
	call strout
	ld a,b
	call HEXOUT
	pop bc		; restore reg
	jp CMD
OUTPORT:
; write data to specified I/O port in page 0
; command format is "O value port#"
	ld hl,outport$	; print command 'O' prompt
	call strout
	call GETHEX	; get value to be output
	jp c,CMD		;abort for non-hex input
	jp z,CMD
	push bc		; save register
	ld b,a		; load value in reg B
	ld hl,outport2$	; print additional prompt for command 'O'
	call strout
	call GETHEX	; get port number into reg A
	jp c,OUTPORT9	;abort for non-hex input
	jp z,OUTPORT9
	ld c,a
	out (c),b		; output data in regB to port in reg C
OUTPORT9:
	pop bc
	jp CMD
LISTHEX:
; list memory as Intel Hex format
; the purpose of command is to save memory as Intel Hex format to console
	ld hl,listhex$	; print command 'L' prompt
	call strout
	call ADRIN	; get address word into reg DE
	jp z,CMD		;return to command prompt if illegal input
	push de		; save for later use
	ld hl,listhex1$	; print second part of 'L' command prompt
	call strout
	call ADRIN	; get end address into reg DE
	jp z,CMD		;return to command prompt if illegal input
listhex1:
	ld hl,CRLF$	; put out a CR, LF	
	call strout
	ld c,10h		; each line contains 16 bytes
	ld b,c		; reg B is the running checksum
	ld a,':'		; start of Intel Hex record
	call cout
	ld a,c		; byte count
	call HEXOUT
	pop hl		; start address in HL
	call ADROUT	; output start address
	ld a,b		; get the checksum
	add a,h		; accumulate checksum
	add a,l		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	xor a		
	call HEXOUT	; record type is 00 (data)
listhex2:
	ld a,(hl)		; get memory pointed by hl
	call HEXOUT	; output the memory value in hex
	ld a,(hl)		; get memory again
	add a,b		; accumulate checksum
	ld b,a		; checksum is kept in reg B
	inc hl
	dec c
	jp nz,listhex2
	ld a,b		; get the checksum
	neg a
	call HEXOUT	; output the checksum
; output 16 memory location, check if reached the end address (saved in reg DE)
; unsign compare: if reg A < reg N, C flag set, if reg A > reg N, C flag clear
	push hl		; save current address pointer
	ld a,h		; get MSB of current address
	cp d		; reg DE contain the end address
;	jp nc,hexend	; if greater, output end-of-file record
	jp c,listhex1	; if less, output more record
	jp nz,hexend	; if greater, output end-of-file record
; if equal, compare the LSB value of the current address pointer
	ld a,l		; now compare the LSB of current address
	cp e
	jp c,listhex1	; if less, output another line of Intel Hex
hexend:
; end-of-record is :00000001FF
	ld hl,CRLF$
	call strout
	ld a,':'		; start of Intel Hex record
	call cout
	xor a
	call HEXOUT	; output "00"
	xor a
	call HEXOUT	; output "00"
	xor a
	call HEXOUT	; output "00"
	ld a,1
	call HEXOUT	; output "01"
	ld a,0ffh
	call HEXOUT	; output "FF"

	pop hl		; clear up the stack

	jp CMD

; print help message
HELP:
	ld hl,HELP$	; print help message
	call strout
	jp CMD
; boot CPM
; copy program from LA9-LA26 (9K) to 0xDC00
; jump to 0xF200 after copy is completed.
BootCPM:
	ld hl,bootcpm$	; print command message
	call strout
	call cin		; get input
	cp '1'		; '1' is user apps
	jp z,bootApps
	cp '2'		; '2' is cpm2.2
	jp z,boot22
	cp '3'		; '3' is cpm3, not implemented
	jp z,boot3
	jp what
boot3:
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,1100h	; CPM3LDR starts from 0x1100
	ld c,CFdata	; reg C points to CF data reg
	ld d,1h		; read from LA 1 to LA 0x0f, 7K--much bigger than needed
readCPM3:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 10h		; between LA1 and LA0fh
	jp z,goCPM3	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	;check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	ld b,0h		;z80
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readCPM3
goCPM3:
	jp 01100h		; BIOS starting address of CP/M

boot22:
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,0d800h	; CPM starts from 0xD800 to 0xFFFF
	ld c,CFdata	; reg C points to CF data reg
	ld d,80h		; read from LA 0x80 to LA 0x94
readCPM1:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 94h		; between LA80h and LA93h
	jp z,goCPM	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	; check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	ld b,0h		;z80
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readCPM1
goCPM:
	jp 0ee00h		; BIOS starting address of CP/M

bootApps:
;restore user application from CF disk to 0x0-0xAFFF
;jump to 0 when done
	ld hl,confirm$	; CRLF to execute the command
	call strout
	call tstCRLF
	jp nz,abort	; abort command if no CRLF

	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld hl,0		; user apps starts from 0x0 to 0xAFFF
	ld c,CFdata	; reg C points to CF data reg
	ld d,11h		; read from LA 0x11 to LA 0x70
readApps:
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; read CPM sector
	cp 69h		; between LA11h and LA68h
	jp z,goApp	; done copying, execute CPM
	out (CF07),a	; 
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	; check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	inir		;z80 read 256 bytes
	ld b,0h		;z80
	inir		;z80 read 256 bytes

	inc d		; read next sector
	jp readApps
goApp:
	jp 0		; User apps starts from 0x0

fillZ:
	ld hl,fill0$	; print fill memory with 0 message
	call strout
	ld b,0		; fill memory with 0
	jp dofill
fillF:
	ld hl,fillf$	; print fill memory with F message
	call strout
	ld b,0ffh		; fill memory with ff
dofill:
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld hl,PROGEND	; start from end of this program
	ld a,0ffh		; end address in reg A
filla:
	ld (hl),b		; write memory location
	inc hl
	cp h		; reached 0xFF00?
	jp nz,filla	; continue til done
	cp l		; reached 0xFFFF?
	jp nz,filla
	ld hl,0b000h	; fill value from 0xB000 down to 0x0000
fillb:
	dec hl
	ld (hl),b		; write memory location with desired value
	ld a,h		; do until h=l=0
	or l
	jp nz,fillb
	jp CMD

; Read CF disk
; data buffer is at 0xC400-C800
; previous data is at 0xC600 for comparison to current data
READRD:
	ld hl,read$	; put out read command message
	call strout
	ld hl,track$	; enter track in hex value
	call strout
	call GETHEX	; get a byte of hex value as track
	jp c,CMD		;abort for non-hex input
	jp z,CMD
	ld (RDtrack),a	; save it 
	ld hl,sector$	; enter sector in hex value
	call strout
	call GETHEX	; get a byte of hex value as sector
	jp c,CMD		;abort for non-hex input
	jp z,CMD
	ld (RDsector),a	; save it
READRD1:
	ld hl,PROGEND	; copy previous block to 0xC700
	ld de,PROGEND+200h
	ld bc,200h	; copy 512 bytes
	ldir		; block copy

	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	ld a,1		; read 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,0		; read first sector
	out (CF1623),a	; high byte of track is always 0
	ld a,(RDsector)	;Z80SBC get sector value
	out (CF07),a	; write sector
	ld a,(RDtrack)
	out (CF815),a
	ld a,20h		; read sector command
	out (CFstat),a	; issue the read sector command
	call chkdrq	; check data request bit set before write CF data
	ld hl,PROGEND	; store CF data starting from C500h
	ld c,CFdata	; reg C points to CF data reg
	ld b,0h		; sector has 256 16-bit data
	inir		;Z80SBC
	ld b,0h		;Z80SBC 2nd half of 512-byte sector
	inir

dumpdata:
	ld d,32		; 32 lines of data
	ld hl,PROGEND	; display 512 bytes of data
dmpdata1:
	push hl		; save hl
	ld hl,CRLF$	; add a CRLF per line
	call strout
	pop hl		; hl is the next address to display
	call DMP16TS	; display 16 bytes per line
	dec d
	jp nz,dmpdata1

	ld hl,PROGEND	; compare with data block in C700h
	ld bc,200h
	ld de,PROGEND+200h
blkcmp:
	ld a,(de)		; get a byte from block in C500h
	inc de
	cpi		; compare with corresponding data in C600h
	jp po,blkcmp1	; exit at end of block compare
	jp z,blkcmp	; exit if data not compare
	ld hl,notsame$	; send out message that data not same as previous read
	call strout
	jp chkRDmore
blkcmp1:	
	ld hl,issame$	; send out message that data read is same as before
	call strout

chkRDmore:
	ld hl,0		;clear sector offset value
	ld (sectoff),hl
	ld hl,RDmore$	; carriage return for next sector of data
	call strout
	call tstCRLF	; look for CRLF
	jp nz,CMD		; 
	ld hl,(RDsector)	; load track & sector as 16-bit value
	inc hl		; increment by 1
	ld (RDsector),hl	; save updated values
	ld hl,track$	; print track & sector value
	call strout
	ld a,(RDtrack)
	call HEXOUT
	ld hl,sector$
	call strout
	ld a,(RDsector)
	call HEXOUT
	jp READRD1
readbsy:
; spin on CF status busy bit
	in a,(CFstat)	; read CF status 
	and 80h		; mask off all except busy bit
	jr nz,readbsy
	ret

; Write CF
;  allowable parameters are '1' for memory from 0x0 to 0xAFFF,
;   '2' for CPM2.2, '3' for CPM3
; Set page I/O to 0, afterward set it back to 0FEh
COPYCF:
	ld hl,copycf$	; print copy message
	call strout
	call cin		; get write parameters
	cp '1'
	jp z,cpApps
	cp '2'
	jp z,CopyCPM2
	cp '3'
	jp z,CopyCPM3
	jp what		; error, abort command
	jp CMD
;test for 'Y'.  Echo back, set Z flag if 'Y' received
tstY:
	call cin		;get a character
	cp 'Y'
	ret
; test for CR or LF.  Echo back. return 0
tstCRLF:
	call cin		; get a character					
	cp 0dh		; if carriage return, output LF
	jp z,tstCRLF1
	cp 0ah		; if line feed, output CR 
	jp z,tstCRLF2
	ret
tstCRLF1:
	ld a,0ah		; put out a LF
	call cout
	xor a		; set Z flag
	ret
tstCRLF2:
	ld a,0dh		; put out a CR
	call cout
	xor a		; set Z flag
	ret

; write CPM to CF
; write data from 0xDC00 to 0xFFFF to CF LA128-LA146 (9K)
CopyCPM2:
	ld hl,0d800h	; CPM starts from 0xD800 to 0xFFFF
	ld de,8094h	; reg DE contains beginning sector and end sector values
	jp wrCF
CopyCPM3:
	ld hl,1100h	; CPMLDR starts from 0x1100
	ld de,0110h	; reg DE contains beginning sector and end sector values
	jp wrCF
cpApps:
; copy the memory contents below 0xB000 to CF flash
	ld hl,0		;start from 0x0
	ld de,1168h	;sectors 11 to sector 68
	jp wrCF

wrCF:
	push hl		; save value
;	ld hl,confirm$	; carriage return to execute the program
	ld hl,copywarn$	;warning file will be overwritten
	call strout
	pop hl
;	call tstCRLF
	call tstY
	jp nz,abort	;abort command if not 'Y'
	ld a,0e0h		; set Logical Address addressing mode
	out (CF2427),a
	xor a		; clear reg A
	out (CF1623),a	; track 0
	out (CF815),a
	ld c,CFdata	; reg C points to CF data reg
wrCF1:
	ld a,1		; write 1 sector
	out (CFsectcnt),a	; write to sector count with 1
	ld a,d		; write CPM sector
	cp e		; reg E contains end sector value
	jp z,wrCFdone	; done copying, execute CPM
	out (CF07),a	; 
	ld a,30h		; write sector command
	out (CFstat),a	; issue the write sector command
	call chkdrq	; check data request bit set before write CF data
	ld b,0h		; sector has 256 16-bit data
	otir		;z80 write 256 bytes
	ld b,0h		;z80
	otir		;z80 wrute 256 bytes

	call readbsy	;wait until busy flag is cleared

	inc d		; write next sector
	jp wrCF1
wrCFdone:
	ld hl,done$	;command completed message
	call strout
	jp CMD
	
TESTRAM:
; test memory from top of this program to 0xFFFE 
	ld hl,testram$	; print test ram message
	call strout
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	jp nz,abort
	ld iy,(testseed)	; a prime number seed, another good prime number is 211
TRagain:
	ld hl,PROGEND	; start testing from the end of this program
	ld de,137		; increment by prime number
	xor a
	ld (currbank),a	;set current bank to 0
	out (bankReg),a
TRLOOP:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	inc hl
	ld (hl),b
	inc hl
	add iy,de		; add a prime number
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRLOOP	; continue until reaching 0xFFFE
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRLOOP
	ld hl,0b000h	; test memory from 0xAFFF down to 0x0000
TR1LOOP:
	push iy
	pop bc		; bounce off stack
	dec hl
	ld (hl),b		; write MSB
	dec hl
	ld (hl),c		; write LSB
	add iy,de		; add a prime number
	ld a,h		; check h=l=0
	or l
	jp nz,TR1LOOP
	ld hl,PROGEND	; verify starting from the end of this program
	ld iy,(testseed)	; starting seed value
TRVER:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jp nz,TRERROR
	inc hl
	ld a,(hl)		; get MSB
	cp b
	jp nz,TRERROR
	inc hl
	add iy,de		; next reference value
	ld a,0ffh		; compare h to 0xff
	cp h
	jp nz,TRVER	; continue verifying til end of memory
	ld a,0feh		; compare l to 0xFE
	cp l
	jp nz,TRVER
	ld hl,0b000h	; verify memory from 0xB000 down to 0x0000
TR1VER:
	push iy		; bounce off stack
	pop bc
	dec hl
	ld a,(hl)		; get MSB from memory
	cp b		; verify
	jp nz,TRERROR
	dec hl
	ld a,(hl)		; get LSB from memory
	cp c
	jp nz,TRERROR
	add iy,de
	ld a,h		; check h=l=0
	or l
	jp nz,TR1VER
TESTRAM8:
	call SPCOUT	; a space delimiter
	ld a,'O'		; put out 'OK' message
	call cout
	ld a,'K'
	call cout
	ld a,(currbank)	
	add a,30h
	call cout
	ld (testseed),iy	; save seed value
	call const	;valid input from console or PS2keyboard?
	jp nz,TESTRAM9	;if Z flag set, exit memory test
;	IN A,(SerStat)	; read on-chip UART receive status
;        	AND 1				;;Z data available?
;        	jp nz,TESTRAM9	; no char, do another iteration of memory test
;test remaining memory, 32K at a time
	ld a,(currbank)	;get the current bank number
	inc a
	cp 3		;topmost page is 0x3
	jp z,TRagain	;start the RAM test from the beginning
	out (bankReg),a	;change 32K bank
	ld (currbank),a	;save the current bank value

	ld hl,7fffh	; start testing from top of 32K
TRLOOPn:
	push iy		; bounce off stack
	pop bc
	ld (hl),c		; write a pattern to memory
	dec hl
	ld (hl),b
	ld a,h		;check for hl reaching 0
	or l
	jp z,bTRVERn
	dec hl
	add iy,de		; add a prime number
	jp TRLOOPn
bTRVERn:
;verify 32K of memory
	ld iy,(testseed)	;start from seed value
	ld hl,7fffh
TRVERn:
	push iy		; bounce off stack
	pop bc
	ld a,(hl)		; get LSB
	cp c		; verify
	jp nz,TRERROR
	dec hl
	ld a,(hl)		; get MSB
	cp b
	jp nz,TRERROR
	ld a,h		;check for hl reaching 0
	or l
	jp z,TESTRAM8
	dec hl
	add iy,de		; next reference value
	jp TRVERn

TESTRAM9
	xor a
	out (bankReg),a	;set RAM page back to 0
	jp CMD		; return to CMD

TRERROR:
	call SPCOUT	; a space char to separate the 'r' command
	ld a,'H'		; display content of HL reg
	call cout		; print the HL label
	ld a,'L'
	call cout
	call SPCOUT	
	call ADROUT	; output the content of HL 	
	jp CMD

;Get an address and jump to it
go:
	ld hl,go$		; print go command message
	call strout
        	CALL ADRIN
	jp z,CMD		;abort command with illegal input
        	LD H,D
        	LD L,E
	push hl		; save go address
	ld hl,confirm$	; get confirmation before executing
	call strout
	call tstCRLF	; check for carriage return
	pop hl
	jp nz,abort
	jp (hl)		; jump to address if CRLF

;;;;;;;;;;;;;;;;;;;;;;;;;;; Utilities from Glitch Works ver 0.1 ;;;;;;;;;;;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;; Copyright (C) 2012 Jonathan Chapman ;;;;;;;;;;;;;;;;;;

;Edit memory from a starting address until X is
;pressed. Display mem loc, contents, and results
;of write.
EDMEM:  	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;return to command prompt if illegal input
        	LD H,D
        	LD L,E
EDMEM1:
	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL ADROUT
        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	CALL SPCOUT
        	CALL DMPLOC
        	CALL SPCOUT
        	CALL GETHEX
        	JP C,CMD		;abort for illegal input
	jp z,EDMEM2	;handle CR, -, x inputs
        	LD (HL),A		
        	CALL SPCOUT
        	CALL DMPLOC
        	INC HL
        	JP EDMEM1
EDMEM2:
;handle non-hexdecimal input of CR, -, x or X
	cp '-'		;go to previous location
	jp nz,EDMEM3
	dec hl
	jp EDMEM1
EDMEM3:
	cp 0dh		;go to next location
	jp nz,CMD		;abort command for all other non-hex input
	inc hl
	jp EDMEM1

;Dump memory between two address locations
MEMDMP: 	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
        	LD H,D
        	LD L,E
        	LD C,10h
        	CALL SPCOUT
        	CALL ADRIN
	jp z,CMD		;abort command if illegal input
MD1:    	LD A,13
        	CALL cout
        	LD A,10
        	CALL cout
        	CALL DMP16
;HL is advanced by $10 after DMP16
;HL = $000x is special case because it means a 64K rollover has occurred
; stop displaying if HL=$000x
	ld a,h
	cp 0		;check for H=0
	jp nz,not000x
	ld a,l		;check for HL=000x
	and 0f0h		;ignore lowest nibble
	cp 0
	jp z,CMD
not000x:
        	LD A,D
        	CP H
;        	JP M,CMD
	jp c,CMD
	jp nz,MD1		;if equal, compare LSB byte
        	LD A,E
        	CP L
;        	JP M,MD2
	jp c,CMD
        	JP MD1
DMP16TS:
; dump memory pointed by HL, 
; print offset from the given track & sector values
;  as the address field
	push hl		; save reg
	ld a,'+'		;print offset symbol
	call cout
	ld hl,(sectoff)	;get offset from track&sector base
	call ADROUT	; output A23..A8
	push bc		;save reg
	ld bc,10h		;add 16 to offset
	add hl,bc
	pop bc
	ld (sectoff),hl	;save it
	pop hl		; restore reg
	jp DMP16D		; display the 16 data field

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMP16 -- Dump 16 consecutive memory locations
;
;pre: HL pair contains starting memory address
;post: memory from HL to HL + 16 printed
;post: HL incremented to HL + 16
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMP16:  	CALL ADROUT
DMP16D:			; 16 consecutive data
;        	CALL SPCOUT
        	LD A,':'
        	CALL cout
        	LD C,10h
	push hl		; save location for later use
DM1:    	
	CALL SPCOUT
        	CALL DMPLOC
        	INC HL		
        	DEC C
	call DMPLOC
	INC HL
	DEC C
	jp nz,DM1

; display the ASCII equivalent of the hex values
	pop hl		; retrieve the saved location
	ld c,10h		; print 16 characters
	call SPCOUT	; insert a space
;	call SPCOUT	; 
dm2:
	ld a,(hl)		; read the memory location
	ld (temp),a	;save temporarily
	cp ' '
	jp m,printdot	; if lesser than 0x20, print a dot
	cp 7fh
	jp m,printchar
printdot:
; for value lesser than 0x20 or 0x7f and greater, print '.'
	ld a,'.'
printchar:
; output printable character
	call cout
;display non-printable character on video monitor
	ld a,(temp)
	push bc
	ld bc,(cursor)	;cursor has advanced one character 
	dec b
	out (c),a
	pop bc
;above is special case to display non-printable char on video display
	inc hl
	dec c
	ret z
	jp dm2

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;DMPLOC -- Print a byte at HL to console
;
;pre: HL pair contains address of byte
;post: byte at HL printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
DMPLOC: 	LD A,(HL)
        	CALL HEXOUT
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXOUT -- Output byte to console as hex
;
;pre: A register contains byte to be output
;post: byte is output to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXOUT: 	PUSH BC
        	LD B,A
        	RRCA
        	RRCA
        	RRCA
        	RRCA
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	LD A,B
        	AND 0Fh
        	CALL HEXASC
        	CALL cout
        	POP BC
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;HEXASC -- Convert nybble to ASCII char
;
;pre: A register contains nybble
;post: A register contains ASCII char
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
HEXASC: 	ADD 90h
        	DAA
        	ADC A,40h
        	DAA
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;ADROUT -- Print an address to the console
;
;pre: HL pair contains address to print
;post: HL printed to console as hex
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
ADROUT: 	LD A,H
        	CALL HEXOUT
        	LD A,L
        	CALL HEXOUT
        	RET

; get hex without echo back
GETHEXQ:
	push de		; save register 
        	CALL cinq
        	CALL ASCHEX
        	RLCA
        	RLCA
        	RLCA
        	RLCA
        	LD D,A
        	CALL cinq
        	CALL ASCHEX
        	OR D 
  	pop de			;restore register
        	RET

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;GOBYT -- Push a two-byte instruction and RET
;         and jump to it
;
;pre: B register contains operand
;pre: C register contains opcode
;post: code executed, returns to caller
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
GOBYT:  	LD HL,0000
        	ADD HL,SP
        	DEC HL
        	LD (HL),0C9h
        	DEC HL
        	LD (HL),B
        	DEC HL
        	LD (HL),C
        	JP (HL)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;SPCOUT -- Print a space to the console
;
;pre: none
;post: 0x20 printed to console
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
SPCOUT: 	LD A,' '
        	CALL cout
        	RET
ADRIN:
	ld de,0		
	call cin
	call ASCHEX	;get a hex value
; none hex value will end command
	jr z,exit0
	ld e,a		;save
backup1:		
	call cin
	cp 8		;backspace?
	jr z,ADRIN	;start over
  	call ASCHEX
;possible options here are 
; backspace
; space to advance command
; other none hex to terminate command
	jr z,exit123
	sla e
	sla e
	sla e
	sla e
	or e
	ld e,a		;save to reg E
getChar3:
	call cin
	cp 8
	jr z,backupE
	call ASCHEX
	jr z,exit123
	call addChar
	call cin
	cp 8
	jr z,delChar
	call ASCHEX
	jr z,exit123	;exit with 3 characters entered
	call addChar
	cp 0		;force clear Z flag 
	ret nz		;return with Zflag cleared
	cp 1
	ret		;return with Z flag cleared
backupE:
;shift regE back a nibble
	srl e
	srl e
	srl e
	srl e
	jr backup1
delChar:
;shift DE back a nibble
	sra d
	rr e
	sra d
	rr e
	sra d
	rr e
	sra d
	rr e
	ld d,0
	jr getChar3
addChar:
;shift DE forward a nibble and add reg A
	sla e
	rl d
	sla e
	rl d
	sla e
	rl d
	sla e
	rl d
	or e
	ld e,a
	ret
exit123
;if space or CR, return with Z flag cleared and valid data in DE
	cp ' '
	jr z,exitGood
	cp 0dh
	jr z,exitGood
exit0:
	xor a		;set Z flag
	ret
exitGood:
	or a		;regA is either space or CR, so this will clear Z flag
	ret

;Get hex in regA
; set C flag to abort the operation <-expect calling routine to chk C flag first
; set Z flag to signal different action for calling routine:
;  x terminate command
;  - go back to previous memory location
;  CR next memory location
GETHEX0:
	call cout		;echo back
	pop de		;start over but first undo the regDE push
GETHEX:
        	CALL cin
        	CALL ASCHEX
;valid first character are:
; hexdecimal value
;  CR,x,-  to be handled by calling routine
;  
	ret z		;not valid hex
	push de
        	LD D,A		;save to combine with 2nd input
        	CALL cinq		;don't automatic echo back on 2nd character
			;supress echo back of CR
;valid second character are:
; hexdecimal value,
; CR: one digit input
; BS: go back to beginning
; otherwise abort the command using C flag for signalling
	cp 8		;back space?
	jr z,GETHEX0	;start over
	cp 0dh		;no echo back for CR
	jr nz,GE0
	or a		;clear Z flag
	ld a,d		;restore the one digit result
	pop de
	ret
GE0:
	call cout		;echo back
	call ASCHEX
	jp z,GE2
	sla d		;shift first hex input to high nibble
	sla d
	sla d
	sla d
        	or d		;combine with 2nd hex input
        	                  ;be careful, this operation may set Z flag is result is zero
        	ld d,1            ;take care of the case when result is 0 and Z flag set
	inc d		;this will clear the Z flag
GE1:    	pop de
	ret
GE2:    	scf
	pop de
	ret
;ASCHEX, convert ASCII to low nibble
;return Z flag set if not 0-9, A-F
; original value in regA returned if not hexdecimal character
ASCHEX: 	
	sub 30h		;ascii 0 is 0x30
	jp m,illegalx
	cp 0ah		;0-9?
	ret m
	sub 11h		;ascii A is 0x41
	jp m,illegaly
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;A-F?
	ret m
	sub 2ah		;ascii a is 0x61
	jp m,illegalz
	add 0ah		;return values from 0xA to 0xF
	cp 10h		;a-f?
	ret m
illegalz
	add 20h-0ah	;return reg A to original value
illegaly
	add 11h
illegalx
	add 30h
	cp a		;set Z flag
	ret		;return with original regA and Z flag set
;send null-terminated string to console
strout: 		
	ld a,(hl)
	or a
	ret z
	call cout
	inc hl
	jr strout
cin:
	call cinq
	jp cout		;cout will return to calling routine

const:
;check if data available from console or PS2 keyboard
;if no data availabe, set Z flag and put 0x0 in regA, otherwise regA is non zero and Z flag cleared
	ld a,(fKIO)	;KIO present?
	rra		;shift flag into carry
	jr nc,constQS
	in a,(SIOACmd)	;check data ready
	bit 0,a
	jr nz,gotDat	;branch if got data from KIO
	jr constPS2	;else check PS2 for input
constQS:
;check input from Quad Serial
	ld a,(fQuadSer)	;Quad serial present?
	rra		;shift flag into carry
	jr nc,constPS2
	in a,(SerStat)	; read Quad Serial receiver status
	and 1		; data available?
	jp nz,gotDat	; if no serial input, check PS2 input available
constPS2:
	ld a,(fPS2Buf)	;first check data in keyboard buffer
	and 1
	jp nz,gotDat	;not necessary to process data for release code (0xF0)
			;this is because routine that set fPS2Buf already processed released code	
	in a,(PS2Stat)	;read keyboard status
	and 1
	ret z		; return with 0 if data not available
;put valid data in bPS2 and set fPS2Buf
	ld a,(fPS2Rel)	;check key release flag; ignore data if flag set
	bit 0,a
	jr z,chkPS2Rel
	xor a
	ld (fPS2Rel),a	;clear key release flag
	in a,(PS2Data)	;read clear status flag
	xor a		; return with 0x0
	ret
chkPS2Rel:
;check PS2 status for data; if not release, store data and set flag
	in a,(PS2Data)
	cp 0f0h		;Is this key release?
	jp nz,gotDat1	;if not release code then real data available
;if release code, ignore current data and next data
	ld a,1
	ld (fPS2Rel),a	;set the key release flag
	xor a		;return with 0x0
	ld (fPS2Buf),a	;clear flag for PS2 data buffer
	ret
gotDat1:
	ld a,1		;set flag for PS2 data available
	ld (fPS2Buf),a
gotDat:
	or 0ffh		; data available, return with 0ffh
	ret

; get char from console without echo
;  RxRdy is D[0]
getSIO:
	in a,(SIOADat)	;get data in reg A
	ret  
getQSer:
	in a,(SerData)	; read data
	ret
cinq:
;no echo back
	ld a,(fKIO)	;use KIO?
	rra		;shift flag to carry
	jr nc,cinQS 
	in a,(SIOACmd)	;check data ready
	bit 0,a
	jr nz,getSIO
 	jr cinPS2
cinQS:
	ld a,(fQuadSer)	;use Quad Serial?
	rra		;shift flag to carry
	jr nc,cinPS2
	in a,(SerStat)	;read status
	and 1		;data ready flag is in D[0]
	jr nz,getQSer
cinPS2:
	ld a,(fPS2Buf)	;first check if data available in buffer
	and 1
	jr z,chkPS2Stat	;if flag not set, skip to check PS2 status reg
	xor a
	ld (fPS2Buf),a	;clear the flag
	jr prcPS2Data	;process PS2 data
chkPS2Stat:
	in a,(PS2Stat)	;read keyboard status
	and 1
	jr z,cinq
	in a,(PS2Data)	;read in PS2 data and store in buffer
	ld (bPS2),a
;process PS2 keyboard input that's in the keyboard buffer
;first check the release flag, if set, clear the flag, then check whether it is shift/ctrl/caplock
;  release.  If not shift/ctrl/caplock release, ignore the incoming data
prcPS2Data:
	ld a,(fPS2Rel)	;check key release flag
	bit 0,a
	jr z,PS2qa
	xor a
	ld (fPS2Rel),a	;clear key release flag
	push hl
	ld hl,PS2Tbl	;check for release of Shift, Caplock or Ctrl keys
	ld a,(bPS2)	;get the release key code from the keyboard buffer
	or l		;combine with index
	ld l,a
	ld a,(hl)		;get scancode
	cp 0e1h		;Shift key released?
	jr nz,Release2
	xor a
	ld (fShift),a	;clear Shift flag
	jp Release9
Release2:
	cp 0e2h		;Ctrl key released?
	jr nz,Release9
	xor a
	ld (fCtrl),a	;clear Ctrl flag
Release9:
	pop hl
	jp cinq
PS2qa:
	ld a,(bPS2)	;get the data from keyboard buffer
	cp 0f0h		;key release code?
	jr nz,KeyInq
	ld a,1		;ignore current data
	ld (fPS2Rel),a	;set flag to mark next data as released key
			;if next data is normal, it will be ignored
			;if next data is shift/ctrl/caplock, the appropriate flag is cleared
	jr cinq
KeyInq:
;CapLock makes key upper case UNLESS shift is pressed then it is lower case
;need to check both shift and CapLock to determine upper or lower case
; exclusive OR shift and CapLock: both 0 means lower case, both 1 means lower case
;   either 1 other 0 means upper case
	push hl
;	ld hl,PS2Tbl	;assuming Shift key not pressed
;	push af
	ld a,(fShift)	;check if Shift key pressed
	ld h,a		;temporary save
	ld a,(fCapLock)	;get CapLock flag
	xor h		;set flag Z set if both 1 or both 0		
	ld hl,PS2Tbl	;assuming Z set
	jr z,KeyInqa
	ld hl,PS2Tbl+80h	;load the Shifted scancode
KeyInqa:
;	pop af
	ld a,(bPS2)	;retrieve data from keyboard buffer
	or l		;PS2Tbl is aligned so l is always 0x80
			;index into the PS2Tbl
	ld l,a		;hl is now points to the key entered
	ld a,(hl)
	cp 0e1h		;if shift key, set Shift flag
	jr nz,KeyInq1
	ld a,1
	ld (fShift),a
	jp KeyInq7
KeyInq1:
	cp 0e2h		;if Ctrl key, set Ctrl flag
	jr nz,KeyInq2
	ld a,1
	ld (fCtrl),a
	jp KeyInq7
KeyInq2:
	cp 0e4h		;if CapLock key, compliment CapLock flag
	jr nz,KeyInq8
	ld a,(fCapLock)
	xor 1		;compliment the flag value
	ld (fCapLock),a
KeyInq7:
;we are not done console input, continue to look for valid key
	pop hl
	jp cinq
KeyInq8:
;before returning as a normal key input, check ctrl flag 
;if ctrl flag set, return key input as ctrl-a to ctrl-z for both upper and lower cases
	ld h,a		;temporary save
	ld a,(fCtrl)
	or a		;set flags
	ld a,h		;restore regA without changing flag
	jr z,KeyInq9
;control key input, assuming input is a-z, A-Z
	and 1fh		;mask off top 3 bits, it becomes ctrl-A to ctrl-Z	for a-z, A-Z	
KeyInq9:
	pop hl
	ret
cout:
; output char in reg A
	push bc
	push af
	ld a,(fKIO)	;use KIO?
	rra		;shift flag bit to carry
	jr nc,coutQS	
;KIO present
coutK1:
	in a,(SIOACmd)	;get status
	bit 2,a		;transmit reg full?
	jr z,coutK1
	pop af		;restore reg
	push af
	out (SIOADat),a	;transmit the character
	jr noSerial
coutQS:
	ld a,(fQuadSer)	;use QuadSerial?
	rra		;shift flag bit to carry
	jr nc,noSerial
coutQ1:
	in a,(SerStat)
	and 40h		;bit 6 is TxEmpty
	jr z,coutQ1
	pop af
	push af
	out (SerData),a
noSerial:
;for video display, check backspace first
	pop af		;recover char in regA
	push af
	ld bc,(cursor)
	cp 8
	jr nz,cout1a
;process backspace, delete current cursor, moving cursor back one character
	ld a,' '
	out (c),a		;blank out current cursor
	dec b		;go back one character
	jp cout8		;exit
cout1a:
	cp 0dh		;carriage return?
	jr nz,cout2
;reg A is free up at this point
	ld a,(prevChar)	;restore previous character at cursor position
	out (c),a
	ld a,0c0h		;mask 
	and b		;set cursor position to first of current line
	ld b,a
	jp cout8		;exit
cout2:
	cp 0ah		;line feed?
	jr nz,cout3
;accumulator A is free up at this point
;if last line, scroll a whole screen
	ld a,(prevChar)	;restore previous character at cursor position
	out (c),a
	ld a,40h
	add a,b		;add a line (64 characters)
	ld b,a		
	jr nc,cout8
chkLastLn:
	ld a,VGAfont-1	;reaching bottom of the screen?
	cp c
	jr nz,cout2a
	call scroll
	ld bc,0c02bh	;set cursor to beginning of last line
	xor a		;blank out the last line
cout2b:
	out (c),a
	inc b
	jr nz,cout2b
	ld bc,0c02bh
	jp cout8
cout3:
	out (c),a		;write to current cursor position
	ld a,b		;if end of line, do not increment cursor position
			;do not write cursor, do not update cursor position
	cp 3fh
	jr z,cout9
	cp 7fh
	jr z,cout9
	cp 0bfh
	jr z,cout9
	cp 0ffh
	jr z,cout9
	inc b		;update cursor position
	jr cout8		;no need to check cursor overflowing to next block-of-4
;	jr nz,cout8	;cursor overflow to next block of 4 lines?
;	jr chkLastLn	;need to check for end of screen and scrolling
cout2a:
	inc c
cout8:
	in a,(c)		;save the character under cursor
	ld (prevChar),a
	ld a,05fh		;write cursor
	out (c),a
cout9a:
	ld (cursor),bc	;update cursor position
cout9:
	pop af
	pop bc
	ret
scroll:
;faster scrolling (6mS) but require 256 byte buffer
;google forum on ZRC, 8/25/2020
;It turns out INDR and OTDR instructions have a difference that I didn't expect 
;(the difference is clearly documented, had I bother to read the documentation).  
;For INDR, reg B content is placed on A15-A8 for the I/O read operation and THEN decremented.  
;For OTDR, reg B is decremented FIRST and the decremented value placed on A15-A8 for the I/O 
;write operation.  
	push hl
	push de
    	ld c,VGAtext        ;C points to top line
mov4ln:
;move lines 2,3,4 to lines 1,2,3
    	ld hl,Scrollbuf+191        ;HL points to buffer
    	ld b,255        ;read line 2,3,4 starting with end of line 4
    	ld a,192
save3ln:
    	ind
    	dec a
    	jp nz,save3ln
;move line 5 to line 4
    	inc c            ;line 5 is next block, b=0-63
    	ld hl,Scrollbuf+255
    	ld b,63
    	indr
    	in a,(c)            ;do the last byte with b=0
    	ld (hl),a
;buf now contains line 2,3,4,5; write it to first block
    	dec c
    	ld hl,Scrollbuf+255
    	ld b,0
    	otdr
;
;do this 11 more times to scroll the entire screen.
	inc c
	ld a,VGAfont		;top of the text display?
	cp c
	jp nz,mov4ln
	pop de
	pop hl
	ret

;scroll:
;slower scroll (8ms) but does not need temporary buffer
;routine that shift the entire video display up one row
;last line is filled with blank
;cursor is positioned at the last line
;	push hl
;	push de
;	ld c,VGAtext		;start from first block-of-4
;scroll0:
;	ld h,192			;move 3 lines
;	ld b,64			;source I/O address
;	ld d,0			;destination I/O address
;scroll1:
;	in a,(c)			;get source value
;	ld e,b
;	ld b,d			;swap source and destination addresses
;	out (c),a
;	ld d,b			;swap source and destination
;	ld b,e
;	inc b
;	inc d
;	dec h
;	jp nz,scroll1
;now scroll the 4th line
;	ld h,64			;do just one line
;scroll2:
;	inc c			;next line is c=c+1, b=0-63
;	in a,(c)			;get source value
;	dec c
;	ld e,b
;	ld b,d			;swap source and destination addresses
;	out (c),a
;	ld d,b			;swap source and destination
;	ld b,e
;	inc b
;	inc d
;	dec h
;	jp nz,scroll2
;finished 4 lines
;	ld a,VGAfont-1		;the end of screen?
;	cp c
;	jr z,scroll3		;exit when scroll completed
;	inc c
;	jp scroll0
;scroll3:
;	pop de
;	pop hl		
;	ret

	

PROGEND:	equ 0c500h		; end of the program, past scroll buffer

signon$:	db "ZALLQ Monitor v0.8b 2/18/23", 13,10,0
;        	db "Format drives command",13,10,0 
KIO$	db "KIO ",0
QuadSer$	db "Quad Serial "
detected$	db "detected",13,10,0
PROMPT$:	db 13, 10, 10, ">", 0
what$:   	db 13, 10, "?", 0
CRLF$	db 13,10,0
confirm$	db " press Return to execute command",0
done$	db " done",0
abort$	db 13,10,"command aborted",0
go$	db "o to address: 0x",0
track$	db " track:0x",0
sector$	db " sector:0x",0
read$	db "ead CF disk",0
RDmore$	db 10,13,"carriage return for next sector, any other key for command prompt",10,13,0
notsame$	db 10,13,"Data NOT same as previous read",10,13,0
issame$	db 10,13,"Data same as previous read",10,13,0
inport$	db "nput from port ",0
invalue$	db 10,13,"Value=",0
outport$	db "utput ",0
outport2$	db " to port ",0
listhex$	db "ist memory as Intel Hex, start address=",0
listhex1$	db " end address=",0
fillf$	db "ill memory with 0xFF",10,13,0
fill0$	db "ero memory",10,13,0
testram$	db "est memory",10,13,0
copywarn$ db 10,13,"Program will be overwritten, enter Y to prceed ",0
xwarn$	db 10,13,"Drive will be formatted, enter Y to proceed ",0
copycf$	db "opy to CF disk",10,13
;	db "0--boot,",10,13
	db "1--User Apps, 0x0-0xAFFF",10,13
	db "2--CP/M2.2:",10,13
	db "3--CP/M3: ",0
	db 0
clrdir$	db " clear disk directories",10,13
	db "A -- drive A,",10,13
	db "B -- drive B:",10,13
	db "C -- drive C,",10,13
	db "D -- drive D,",10,13	
;	db "E -- RAM drive: ",0
	db 0
bootcpm$	db "oot CP/M",10,13
	db "1--User Apps,",10,13
	db "2--CP/M2.2:",10,13
	db "3--CP/M3: ",0
	db 0
HELP$	db "elp",13,10
	db "G <addr> CR",13,10
	db "D <start addr> <end addr>",13,10
	db "I <port>",13,10
	db "O <value> <port>",13,10
	db "L <start addr> <end addr>",13,10
	db "Z CR",13,10
	db "F CR",13,10
	db "T CR",13,10
	db "E <addr>",13,10
HELPCF$	db "R <track> <sector>",13,10
	db "X <options> CR",13,10
	db "B <options> CR",13,10
	db "C <options> CR",0

	ORG 0c300h
;scan code for PS2 keyboard
;place the data block on $c300 and $c380
;$Fx are function keys, eg, $f1 is function key 1
;$Ex are secondary keys, eg, $e1 is SHIFT key, $e2 is CTRL key, $e3 is ALT key, 
;   $e4 is CAP lock,$e5 is NUM lock, $e6 is SCROLL lock
PS2Tbl:
;0x0-0x7
	db 0,0f9h,0,0f5h,0f3h,0f1h,0f2h,0fch
;0x8-0xF
	db 0,0fah,0f8h,0f6h,0f4h,09,027h,0
;0x10-0x17
	db 0,0e3h,0e1h,0,0e2h,'q','1',0
;0x18-0x1F
	db 0,0,'z','s','a','w','2',0
;0x20-0x27
	db 0,'c','x','d','e','4','3',0
;0x28-0x2F
	db 0,' ','v','f','t','r','5',0
;0x30-0x37
	db 0,'n','b','h','g','y','6',0
;0x38-0x3F
	db 0,0,'m','j','u','7','8',0
;0x40-0x47
	db 0,',','k','i','o','0','9',0
;0x48-0x4F
	db 0,'.','/','l',';','p','-',0
;0x50-0x57
	db 0,0,027h,0,'[','=',0,0
;0x58-0x5F
	db 0e4h,0e1h,0dh,']',0,05ch,0,0
;0x60-0x67
	db 0,0,0,0,0,0,08h,0
;0x68-0x6F
	db 0,'1',0,0,'7',0,0,0
;0x70-0x77
	db '0',0,'2','5','6','8',01bh,0e5h
;0x78-0x7F
	db 0fbh,'+','3','-','*','9',0e6h,0
;;;;;;;;;;;Shifted scan code;;;;;;;;;;;;;;
;0x0-0x7
	db 0,0f9h,0,0f5h,0f3h,0f1h,0f2h,0fch
;0x8-0xF
	db 0,0fah,0f8h,0f6h,0f4h,09,027h,0
;0x10-0x17
	db 0,0e3h,0e1h,0,0e2h,'Q','!',0
;0x18-0x1F
	db 0,0,'Z','S','A','W','@',0
;0x20-0x27
	db 0,'C','X','D','E','$','#',0
;0x28-0x2F
	db 0,' ','V','F','T','R','%',0
;0x30-0x37
	db 0,'N','B','H','G','Y','^',0
;0x38-0x3F
	db 0,0,'M','J','U','&','*',0
;0x40-0x47
	db 0,'"','K','I','O',')','(',0
;0x48-0x4F
	db 0,'>','?','L',':','P','-',0
;0x50-0x57
	db 0,0,'"',0,'{','+',0,0
;0x58-0x5F
	db 0e4h,0e1h,0dh,'}',0,'|',0,0
;0x60-0x67
	db 0,0,0,0,0,0,08h,0
;0x68-0x6F
	db 0,'!',0,0,'&',0,0,0
;0x70-0x77
	db '0',0,'2','5','6','8',01bh,0e5h
;0x78-0x7F
	db 0fbh,'+','3','-','*','9',0e6h,0
	ORG 0c400h
Scrollbuf:	ds 256		;temporary buffer for fast scrolling
	END


