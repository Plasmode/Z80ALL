/* Quartus II Version 8.1 Build 163 10/28/2008 SJ Full Version */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM7128SL84) Path("C:/quartwrk81/HomeProjects/Z80ALL/archive/rev3pcb_84plcc/") File("top.pof") MfrSpec(OpMask(3));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
